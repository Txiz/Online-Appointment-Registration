import request from '@/utils/request'

export default {
  // 分页查询所有医院信息列表
  pageHospitalInfo(current, size, hospitalInfoQueryVo) {
    return request({
      url: `/hospital/hospital-info/page/${current}/${size}`,
      method: 'post',
      data: hospitalInfoQueryVo
    })
  },
  // 更新医院状态，上线医院
  updateStatus(id, status) {
    return request({
      url: `/hospital/hospital-info/updateStatus/${id}/${status}`,
      method: 'get'
    })
  },
  // 根据表id获取医院信息
  getHospitalInfo(id) {
    return request({
      url: `/hospital/hospital-info/${id}`,
      method: 'get'
    })
  },
  // 根据表id查询子数据字典
  listDataDictionary(id) {
    return request({
      url: `/hospital/data-dictionary/list/${id}`,
      method: 'get'
    })
  },
  // 根据医院编号和科室编号分页查询排班规则
  getScheduleRule(current, size, hospitalCode, departmentCode) {
    return request({
      url: `/hospital/schedule/getScheduleRule/${current}/${size}/${hospitalCode}/${departmentCode}`,
      method: 'get'
    })
  },
  // 根据医院编号、科室编号和工作日期查询工作计划
  getSchedule(hospitalCode, departmentCode, workDate) {
    return request({
      url: `/hospital/schedule/getSchedule/${hospitalCode}/${departmentCode}/${workDate}`,
      method: 'get'
    })
  },
  // 根据医院编号查询所有的部门科室并组装成列表树
  listDepartmentVo(hospitalCode) {
    return request({
      url: `/hospital/department/list/${hospitalCode}`,
      method: 'get'
    })
  }
}
