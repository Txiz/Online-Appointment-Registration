import request from '@/utils/request'

export default {
  // 保存医院集合
  saveHospitalSet(hospitalSet) {
    return request({
      url: `/hospital/hospital-set/save`,
      method: 'post',
      data: hospitalSet
    })
  },
  // 更新医院集合
  updateHospitalSet(hospitalSet) {
    return request({
      url: `/hospital/hospital-set/update`,
      method: 'post',
      data: hospitalSet
    })
  },
  // 根据表id逻辑删除医院集合
  removeHospitalSet(id) {
    return request({
      url: `/hospital/hospital-set/${id}`,
      method: 'delete'
    })
  },
  // 根据表id获取医院集合
  getHospitalSet(id) {
    return request({
      url: `/hospital/hospital-set/${id}`,
      method: 'get'
    })
  },
  // 查询所有医院集合列表
  listHospitalSet() {
    return request({
      url: `/hospital/hospital-set/list`,
      method: 'get'
    })
  },
  // 分页查询所有医院集合列表
  pageHospitalSet(current, size, hospitalSetQueryVo) {
    return request({
      url: `/hospital/hospital-set/page/${current}/${size}`,
      method: 'post',
      data: hospitalSetQueryVo
    })
  },
  // 跟据表id锁定医院集合
  lockHospitalSet(id, status) {
    return request({
      url: `/hospital/hospital-set/lock/${id}/${status}`,
      method: 'put'
    })
  },
  // 根据表id获取签名密钥
  getSignKeyById(id) {
    return request({
      url: `/hospital/hospital-set/getSignKey/${id}`,
      method: 'put'
    })
  }
}
