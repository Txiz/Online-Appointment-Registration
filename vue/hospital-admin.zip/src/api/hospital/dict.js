import request from '@/utils/request'

export default {
  // 导入数据字典
  importDataDictionary(file) {
    return request({
      url: `/hospital/data-dictionary/import`,
      method: 'post',
      data: file
    })
  },
  // 导出数据字典
  exportDataDictionary() {
    return request({
      url: `/hospital/data-dictionary/export`,
      method: 'post'
    })
  },
  // 根据表id查询子数据字典
  listDataDictionary(id) {
    return request({
      url: `/hospital/data-dictionary/list/${id}`,
      method: 'get'
    })
  }
}
