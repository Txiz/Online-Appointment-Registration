import request from '@/utils/request'

export default {
  // 根据id查询公告
  getNotice(noticeId) {
    return request({
      url: `/hospital/notice/${noticeId}`,
      method: 'get'
    })
  },
  // 保存公告
  saveNotice(notice) {
    return request({
      url: `/hospital/notice/save`,
      method: 'post',
      data: notice
    })
  },
  // 更新公告
  updateNotice(notice) {
    return request({
      url: `/hospital/notice/update`,
      method: 'post',
      data: notice
    })
  },
  // 分页查询公告
  pageNotice(current, size, noticeQueryVo) {
    return request({
      url: `/hospital/notice/page/${current}/${size}`,
      method: 'post',
      data: noticeQueryVo
    })
  },
  // 启用公告
  enableNotice(noticeId, isEnable) {
    return request({
      url: `/hospital/notice/enable/${noticeId}/${isEnable}`,
      method: 'put'
    })
  },
  // 根据id删除公告
  removeNotice(noticeId) {
    return request({
      url: `/hospital/notice/${noticeId}`,
      method: 'delete'
    })
  }
}
