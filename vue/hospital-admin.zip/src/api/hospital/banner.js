import request from '@/utils/request'

export default {
  // 保存轮播图
  saveBanner(banner) {
    return request({
      url: `/hospital/banner/save`,
      method: 'post',
      data: banner
    })
  },
  // 分页查询轮播图
  pageBanner(current, size) {
    return request({
      url: `/hospital/banner/page/${current}/${size}`,
      method: 'post'
    })
  },
  // 根据id删除轮播图
  removeBanner(bannerId) {
    return request({
      url: `/hospital/banner/${bannerId}`,
      method: 'delete'
    })
  },
  // 启用轮播图
  enableBanner(bannerId, isEnable) {
    return request({
      url: `/hospital/banner/enable/${bannerId}/${isEnable}`,
      method: 'put'
    })
  }
}
