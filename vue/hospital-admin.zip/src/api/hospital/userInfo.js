import request from '@/utils/request'

export default {
  // 分页查询所有用户信息列表
  pageUserInfo(current, size, userQueryVo) {
    return request({
      url: `/hospital/user-info/page/${current}/${size}`,
      method: 'post',
      data: userQueryVo
    })
  },
  // 根据表id锁定用户信息
  lockUserInfo(id, isEnable) {
    return request({
      url: `/hospital/user-info/lock/${id}/${isEnable}`,
      method: 'get'
    })
  },
  // 根据表id获取用户信息
  getUserInfoById(id) {
    return request({
      url: `/hospital/user-info/${id}`,
      method: 'get'
    })
  },
  // 根据表id认证用户信息
  approvalUserInfo(id, authStatus) {
    return request({
      url: `/hospital/user-info/approval/${id}/${authStatus}`,
      method: 'get'
    })
  }
}
