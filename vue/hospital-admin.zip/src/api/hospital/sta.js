import request from '@/utils/request'

export default {
  getCurrentStatisticsNum() {
    return request({
      url: `/hospital/statistics/getCurrentStatisticsNum`,
      method: 'get'
    })
  },
  pageStatistics(current, size, statisticsQueryVo) {
    return request({
      url: `/hospital/statistics/page/${current}/${size}`,
      method: 'post',
      data: statisticsQueryVo
    })
  },
  deleteById(statisticsId) {
    return request({
      url: `/hospital/statistics/${statisticsId}`,
      method: 'delete'
    })
  },
  getStatisticsDataForMap() {
    return request({
      url: `/hospital/statistics/getStatisticsDataForMap`,
      method: 'get'
    })
  }
}
