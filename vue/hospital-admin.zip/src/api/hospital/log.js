import request from '@/utils/request'

// export function pageLog(current, size, logQueryVo) {
//   return request({
//     url: `/task/log/page/${current}/${size}`,
//     method: 'post',
//     data: logQueryVo
//   })
// }
export default {
  // 保存异常日志
  saveLog(log) {
    return request({
      url: `/hospital/log/save`,
      method: 'post',
      data: log
    })
  },
  // 分页查询异常日志
  pageLog(current, size, logQueryVo) {
    return request({
      url: `/hospital/log/page/${current}/${size}`,
      method: 'post',
      data: logQueryVo
    })
  },
  // 删除异常日志
  removeLog(logId) {
    return request({
      url: `/hospital/log/${logId}`,
      method: 'delete'
    })
  }
}
