import request from '@/utils/request'

export function login(data) {
  return request({
    url: '/hospital/user-info/loginByPhone',
    method: 'post',
    data
  })
}

export function getInfo() {
  return request({
    url: '/hospital/user-info/get',
    method: 'get'
  })
}
