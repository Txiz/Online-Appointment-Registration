<template>
  <div class="app-container">
    <el-card>
      <el-form :inline="true" class="demo-form-inline">
        <el-form-item>
          <el-select
            v-model="searchObj.provinceCode"
            placeholder="请选择省"
            @change="provinceChanged"
          >
            <el-option
              v-for="item in provinceList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-select
            v-model="searchObj.cityCode"
            placeholder="请选择市"
          >
            <el-option
              v-for="item in cityList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-input v-model="searchObj.hospitalName" placeholder="医院名称" />
        </el-form-item>
        <el-button type="primary" icon="el-icon-search" @click="fetchData()">查询</el-button>
        <el-button type="default" icon="el-icon-refresh" @click="resetData()">清空</el-button>
      </el-form>
      <!-- banner列表 -->
      <el-table
        v-loading="listLoading"
        :data="list"
        border
        fit
        highlight-current-row
      >
        <el-table-column
          label="序号"
          width="60"
          align="center"
        >
          <template slot-scope="scope">
            {{ (page - 1) * limit + scope.$index + 1 }}
          </template>
        </el-table-column>
        <el-table-column label="医院图标">
          <template slot-scope="scope">
            <img :src="'data:image/jpeg;base64,'+scope.row.logoData" width="80">
          </template>
        </el-table-column>
        <el-table-column prop="hospitalName" label="医院名称" />
        <el-table-column prop="hospitalType" label="等级" width="90" />
        <el-table-column prop="address" label="详情地址" />
        <el-table-column label="状态" width="80">
          <template slot-scope="scope">
            {{ scope.row.status === 0 ? '未上线' : '已上线' }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="230" align="center">
          <template slot-scope="scope">
            <router-link :to="'/hospSet/hospital/show/'+scope.row.id">
              <el-button class="table_button" type="primary" size="mini">查看</el-button>
            </router-link>
            <router-link :to="'/hospSet/hospital/schedule/'+scope.row.hospitalCode">
              <el-button class="table_button" type="primary" size="mini">排班</el-button>
            </router-link>
            <el-button v-if="scope.row.status == 1" class="table_button" type="danger" size="mini" @click="updateStatus(scope.row.id, 0)">下线</el-button>
            <el-button v-if="scope.row.status == 0" class="table_button" type="success" size="mini" @click="updateStatus(scope.row.id, 1)">上线</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页组件 -->
      <el-pagination
        :current-page="page"
        :total="total"
        :page-size="limit"
        :page-sizes="[5, 10, 20, 30, 40, 50, 100]"
        style="padding: 30px 0; text-align: center;"
        layout="sizes, prev, pager, next, jumper, ->, total, slot"
        @current-change="fetchData"
        @size-change="changeSize"
      />
    </el-card>
  </div>
</template>
<script>
import hospApi from '@/api/hospital/hosp'
export default {
  data() {
    return {
      listLoading: true, // 数据是否正在加载
      list: [], // 医院列表数据集合
      total: 0, // 数据库中的总记录数
      page: 1, // 默认页码
      limit: 10, // 每页记录数
      searchObj: {}, // 查询表单对象
      provinceList: [], // 所有省集合
      cityList: [] // 所有市集合
    }
  },
  created() {
    // 调用医院列表
    this.fetchData()
    // 调用查询所有省的方法
    this.findAllProvince()
  },
  methods: {
    // 更新医院上线状态
    updateStatus(id, status) {
      hospApi.updateStatus(id, status)
        .then(response => {
          // 刷新页面
          this.fetchData(1)
        })
    },
    // 医院列表
    fetchData(page = 1) {
      this.page = page
      console.log(this.searchObj)
      hospApi.pageHospitalInfo(this.page, this.limit, this.searchObj)
        .then(response => {
          console.log(this.searchObj)
          // 每页数据集合
          this.list = response.data.hospitalInfoList.content
          console.log(this.list)
          // 总记录数
          this.total = response.data.hospitalInfoList.totalElements
          // 加载图表不显示
          this.listLoading = false
        })
    },
    // 查询所有省
    findAllProvince() {
      hospApi.listDataDictionary(86)
        .then(response => {
          this.provinceList = response.data.DataDictionary
        })
    },
    // 重置查询表单
    resetData() {
      console.log('重置查询表单')
      this.searchObj = {}
      this.cityList = []
      this.fetchData()
    },
    // 点击某个省，显示里面市（联动）
    provinceChanged() {
      // 初始化值
      this.cityList = []
      this.searchObj.cityCode = ''
      // 调用方法，根据省id，查询下面子节点
      hospApi.listDataDictionary(this.searchObj.provinceCode)
        .then(response => {
          this.cityList = response.data.DataDictionary
        })
    },
    // 分页，页码变化
    changeSize(newlimit) {
      this.limit = newlimit
      this.fetchData(1)
    }
  }
}
</script>
<style scoped>
  .table_button {
    margin-left: 10px;
  }
</style>
