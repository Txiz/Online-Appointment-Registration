<template>
  <div class="app-container">
    <el-card class="box-card">
      <!-- 走马灯 -->
      <el-carousel height="500px">
        <el-carousel-item v-for="item in bannerList" :key="item.bannerId">
          <el-image
            :src="item.bannerUrl"
          />
        </el-carousel-item>
      </el-carousel>
    </el-card>
    <el-card class="box-card">
      <!-- 功能按钮 -->
      <el-upload
        class="upload-demo"
        action="#"
        :http-request="savePicture"
      >
        <el-button type="primary" icon="el-icon-plus">添加</el-button>
      </el-upload>
      <!-- 分类列表 -->
      <el-table :data="bannerList" row-key="bannerId">
        <el-table-column label="序号" type="index" />
        <el-table-column label="轮播图" width="150">
          <template v-slot="scope">
            <el-image
              :src="scope.row.bannerUrl"
              fit="cover"
            />
          </template>
        </el-table-column>
        <el-table-column label="是否上线" prop="isEnable">
          <template slot-scope="scope">
            {{ scope.row.isEnable === 1 ? '上线' : '下线' }}
          </template>
        </el-table-column>
        <el-table-column label="创建时间">
          <template v-slot="scope">{{ scope.row.createTime }}</template>
        </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template v-slot="scope">
            <el-button v-if="scope.row.isEnable == 1" class="table_button" type="info" icon="el-icon-bottom" size="mini" @click="enableBanner(scope.row, 0)" />
            <el-button v-if="scope.row.isEnable == 0" class="table_button" type="success" icon="el-icon-top" size="mini" @click="enableBanner(scope.row, 1)" />
            <el-button class="table_button" type="danger" icon="el-icon-delete" size="mini" @click="deleteBannerById(scope.row.bannerId)" />
          </template>
        </el-table-column>
      </el-table>
      <!--分页插件-->
      <el-pagination
        :current-page="page"
        :page-sizes="[10, 20, 50]"
        :page-size="size"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
  </div>
</template>

<script>

import BannerApi from '@/api/hospital/banner'
import OssApi from '@/api/task/oss'

export default {
  data() {
    return {
      bannerList: [],
      total: 0,
      page: 1,
      size: 10,
      saveForm: { bannerUrl: '' }
    }
  },
  created() {
    this.pageBanner()
  },
  methods: {
    // 保存轮播图
    saveBanner() {
      BannerApi.saveBanner(this.saveForm)
        .then(response => {
          this.pageBanner()
        })
    },
    // 分页查询轮播图
    pageBanner(page = 1) {
      this.page = page
      BannerApi.pageBanner(this.page, this.size)
        .then(response => {
          this.bannerList = response.data.bannerList
          this.total = response.data.total
        })
    },
    deleteBannerById(bannerId) {
      this.$confirm('此操作将删除该标签，是否删除?', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        BannerApi.removeBanner(bannerId)
          .then(response => {
            this.pageBanner()
          })
      })
    },
    enableBanner(row, status) {
      BannerApi.enableBanner(row.bannerId, status)
        .then(response => {
          this.pageBanner()
        })
    },
    // 分页插件，监听size改变事件
    handleSizeChange(newSize) {
      this.size = newSize
      this.pageBanner()
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(newPage) {
      this.page = newPage
      this.pageBanner(this.page)
    },
    // 上传组件
    savePicture(param) {
      const fd = new FormData()
      fd.append('file', param.file)
      OssApi.uploadPicture(fd)
        .then(response => {
          console.log(response)
          this.saveForm.bannerUrl = response.data.url
          this.saveBanner()
        })
    }
  }
}
</script>

<style scoped>
  .table_button {
    margin-left: 10px;
  }
</style>
