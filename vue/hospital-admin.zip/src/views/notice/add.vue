<template>
  <div class="app-container">
    <el-card>
      <el-form label-width="120px">
        <el-form-item label="公告类型">
          <!-- <el-input v-model="noticeList.noticeType" /> -->
          <el-select v-model="noticeList.noticeType" placeholder="请选择公告类型">
            <el-option
              v-for="item in noticeTypeList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="公告标题">
          <el-input v-model="noticeList.noticeTitle" />
        </el-form-item>
        <el-form-item label="公告内容">
          <el-input v-model="noticeList.noticeContent" />
        </el-form-item>
        <el-form-item label="公告截止时间">
          <el-date-picker v-model="noticeList.noticeEndTime" type="datetime" value-format="yyyy-MM-dd HH:mm:ss" default-time="00:00:00" />
        </el-form-item>
        <el-form-item label="是否上线">
          <!-- <el-input v-model="noticeList.isEnable" /> -->
          <el-select v-model="noticeList.isEnable" placeholder="请选择是否上线">
            <el-option
              v-for="item in noticeEnableList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" class="table_button" @click="saveOrUpdate">保存</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>
<script>
import noticeApi from '@/api/hospital/notice'

export default {
  data() {
    return {
      noticeList: {},
      noticeTypeList: [{
        value: '0',
        label: '平台公告'
      }, {
        value: '1',
        label: '医院公告'
      }],
      noticeEnableList: [{
        value: '0',
        label: '下线'
      }, {
        value: '1',
        label: '上线'
      }]
    }
  },
  created() { // 页面渲染之前执行
    // 获取路由id值
    // 调用接口得到公告信息
    if (this.$route.params && this.$route.params.noticeId) {
      const noticeId = this.$route.params.noticeId
      this.getNotice(noticeId)
    } else {
      // 表单数据清空
      this.noticeList = {}
    }
  },
  methods: {
    // 根据id查询
    getNotice(noticeId) {
      noticeApi.getNotice(noticeId)
        .then(response => {
          this.noticeList = response.data.notice
        })
    },
    // 添加
    save() {
      noticeApi.saveNotice(this.noticeList)
        .then(response => {
          // 提示
          this.$message({
            type: 'success',
            message: '添加成功!'
          })
          // 跳转列表页面，使用路由跳转方式实现
          this.$router.push({ path: '/notice/list' })
        })
    },
    // 修改
    update() {
      noticeApi.updateNotice(this.noticeList)
        .then(response => {
          // 提示
          this.$message({
            type: 'success',
            message: '修改成功!'
          })
          // 跳转列表页面，使用路由跳转方式实现
          this.$router.push({ path: '/notice/list' })
        })
    },
    saveOrUpdate() {
      // 判断添加还是修改
      if (!this.noticeList.noticeId) { // 没有id，做添加
        this.save()
      } else { // 修改
        this.update()
      }
    }
  }
}
</script>
<style scoped>
  .table_button {
    margin-left: 10px;
  }
</style>
