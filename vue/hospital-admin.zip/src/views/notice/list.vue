<template>
  <div class="app-container">
    <!--查询表单-->
    <el-form :inline="true" class="demo-form-inline">
      <el-form-item>
        <el-input v-model="searchObj.noticeTitle" placeholder="公告标题" />
      </el-form-item>

      <el-form-item label="创建时间">
        <el-date-picker
          v-model="searchObj.beginTime"
          type="datetime"
          placeholder="选择开始时间"
          value-format="yyyy-MM-dd HH:mm:ss"
          default-time="00:00:00"
        />
      </el-form-item>
      至
      <el-form-item>
        <el-date-picker
          v-model="searchObj.endTime"
          type="datetime"
          placeholder="选择截止时间"
          value-format="yyyy-MM-dd HH:mm:ss"
          default-time="00:00:00"
        />
      </el-form-item>

      <el-button type="primary" icon="el-icon-search" @click="fetchData()">查询</el-button>
      <el-button type="default" @click="resetData()">清空</el-button>
    </el-form>
    <!-- 公告列表 -->
    <el-table
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      :data="noticeList"
      row-key="noticeId"
    >
      <el-table-column label="序号" type="index" />
      <el-table-column label="公告类型">
        <template v-slot="scope">
          <el-tag
            :type="items[scope.row.noticeType].type"
          >
            {{ items[scope.row.noticeType].label }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="公告标题" prop="noticeTitle" />
      <el-table-column label="公告内容" prop="noticeContent" />
      <el-table-column label="公告截止时间" prop="noticeEndTime" />
      <el-table-column label="是否锁定" prop="isEnable">
        <template slot-scope="scope">
          {{ scope.row.isEnable === 1 ? '正常' : '锁定' }}
        </template>
      </el-table-column>
      <el-table-column label="创建时间" prop="createTime" />
      <el-table-column label="更新时间" prop="updateTime" />
      <el-table-column label="操作">
        <template v-slot="scope">
          <router-link :to="'/notice/edit/'+scope.row.noticeId">
            <el-button class="table_button" type="primary" icon="el-icon-edit" circle />
          </router-link>
          <el-button v-if="scope.row.isEnable == 1" type="primary" circle @click="enableNotice(scope.row,0)">锁定</el-button>
          <el-button v-if="scope.row.isEnable == 0" type="danger" circle @click="enableNotice(scope.row, 1)">解锁</el-button>
          <el-button
            class="table_button"
            type="danger"
            icon="el-icon-delete"
            circle
            @click="deleteByNoticeId(scope.row.noticeId)"
          />
        </template>
      </el-table-column>
    </el-table>
    <!--分页插件-->
    <el-pagination
      :current-page="page"
      :page-sizes="[50, 100, 200]"
      :page-size="size"
      :total="total"
      layout="total, sizes, prev, pager, next, jumper"
      background
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
  </div>
</template>

<script>

import noticeApi from '@/api/hospital/notice'

export default {
  data() {
    return {
      noticeList: [],
      total: 0,
      page: 1,
      size: 50,
      searchObj: {},
      loading: true,
      items: [
        { type: 'success', label: '平台公告' },
        { type: '', label: '医院公告' }
      ]
    }
  },
  created() {
    this.loading = true
    this.pageNotice()
    this.loading = false
  },
  methods: {
    // 调用api层获取数据库中的数据
    fetchData(page = 1) {
      console.log('翻页。。。' + page)
      // 异步获取远程数据（ajax）
      this.page = page
      noticeApi.pageNotice(this.page, this.size, this.searchObj).then(
        response => {
          this.noticeList = response.data.noticeList
          this.total = response.data.total
          // 数据加载并绑定成功
          this.listLoading = false
        }
      )
    },
    pageNotice(page = 1) {
      this.page = page
      noticeApi.pageNotice(this.page, this.size, this.searchObj)
        .then(response => {
          this.noticeList = response.data.noticeList
          this.total = response.data.total
        })
    },
    deleteByNoticeId(noticeId) {
      this.$confirm('此操作将删除该标签，是否删除?', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        noticeApi.removeNotice(noticeId)
          .then(response => {
            this.pageNotice()
          })
      })
    },
    enableNotice(row, status) {
      noticeApi.enableNotice(row.noticeId, status)
        .then(response => {
          this.pageNotice()
        })
    },
    // 重置查询表单
    resetData() {
      console.log('重置查询表单')
      this.searchObj = {}
      this.fetchData()
    },
    // 分页插件，监听size改变事件
    handleSizeChange(newSize) {
      this.size = newSize
      this.pageNotice()
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(newPage) {
      this.page = newPage
      this.pageNotice(this.page)
    }
  }
}
</script>

<style scoped>
.table_button {
  margin-left: 10px;
}
</style>
