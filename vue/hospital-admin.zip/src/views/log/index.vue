<template>
  <div class="app-container">
    <!-- 操作日志列表 -->
    <el-table
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      :data="logList"
      row-key="logId"
    >
      <el-table-column label="序号" type="index" />
      <el-table-column label="日志类型">
        <template v-slot="scope">
          <el-tag
            :type="items[scope.row.logType].type"
          >
            <!-- {{ scope.row.logType==0 ? '登录日志' : scope.row.logType==1 ? '操作日志' : scope.row.logType==2 ? '异常日志' : '外部请求' }} -->
            {{ items[scope.row.logType].label }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="用户名称" prop="username" min-width="110" />
      <el-table-column label="请求接口" prop="uri" min-width="250" />
      <el-table-column label="请求方法" prop="method" />
      <el-table-column label="方法描述" prop="description" />
      <el-table-column
        label="异常信息"
        prop="error"
        show-overflow-tooltip
      />
      <el-table-column label="ip地址" prop="ip" />
      <el-table-column label="ip来源" prop="ipSource" />
      <el-table-column label="操作系统" prop="os" />
      <el-table-column label="浏览器" prop="browser" />
      <el-table-column label="创建时间" prop="createTime" />
      <el-table-column label="操作">
        <template v-slot="scope">
          <el-button
            class="table_button"
            type="danger"
            icon="el-icon-delete"
            circle
            @click="deleteByLogId(scope.row.logId)"
          />
        </template>
      </el-table-column>
    </el-table>
    <!--分页插件-->
    <el-pagination
      :current-page="page"
      :page-sizes="[50, 100, 200]"
      :page-size="size"
      :total="total"
      layout="total, sizes, prev, pager, next, jumper"
      background
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
  </div>
</template>

<script>

import logApi from '@/api/hospital/log'

export default {
  data() {
    return {
      logList: [],
      total: 0,
      page: 1,
      size: 50,
      searchObj: {},
      loading: true,
      items: [
        { type: 'success', label: '登录日志' },
        { type: '', label: '操作日志' },
        { type: 'danger', label: '异常日志' },
        { type: 'warning', label: '外部请求' }
      ]
    }
  },
  created() {
    this.loading = true
    this.pageLog()
    this.loading = false
  },
  methods: {
    pageLog(page = 1) {
      this.page = page
      logApi.pageLog(this.page, this.size, this.searchObj)
        .then(response => {
          this.logList = response.data.logPageList
          this.total = response.data.total
        })
    },
    deleteByLogId(logId) {
      this.$confirm('此操作将删除该标签，是否删除?', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        logApi.removeLog(logId)
          .then(response => {
            this.pageLog()
          })
      })
    },
    // 分页插件，监听size改变事件
    handleSizeChange(newSize) {
      this.size = newSize
      this.pageLog()
    },
    // 分页插件，监听page改变的事件
    handleCurrentChange(newPage) {
      this.page = newPage
      this.pageLog(this.page)
    }
  }
}
</script>

<style scoped>
.table_button {
  margin-left: 10px;
}
</style>
