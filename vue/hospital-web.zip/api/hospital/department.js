import request from '/utils/request'

const api_name = `/hospital/department`

export default {
  listDepartmentVo(hospitalCode){
    return request({
      url :`${api_name}/list/${hospitalCode}`,
      method:'get'
    })
  }
}
