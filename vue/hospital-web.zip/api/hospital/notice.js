import request from '@/utils/request'

export default {
  // 根据id查询公告
  getNotice(noticeId) {
    return request({
      url: `/hospital/notice/${noticeId}`,
      method: 'get'
    })
  },
  // 分页查询公告
  pageNotice(current, size, noticeQueryVo) {
    return request({
      url: `/hospital/notice/page/${current}/${size}`,
      method: 'post',
      data: noticeQueryVo
    })
  },
  //查询公告列表
  listNotice() {
    return request({
      url: `/hospital/notice/list`,
      method: 'get',
    })
  },
}
