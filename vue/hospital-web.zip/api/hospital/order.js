import request from '@/utils/request' 

export default {
  //保存订单
  saveOrder(scheduleId, patientId){
    return request({
      url: `/hospital/order/save/${scheduleId}/${patientId}`,
      method: 'get'
    })
  },
  //分页查询所有订单列表
  pageOrder(current, size, orderQueryVo){
    return request({
      url: `/hospital/order/page/${current}/${size}`,
      method: 'post',
      data: orderQueryVo
    })
  },
  //获取订单状态
  listOrderStatus(){
    return request({
      url: `/hospital/order/listOrderStatus`,
      method: 'get',
    })
  },
  //根据表id查询订单信息
  getOrder(orderId){
    return request({
      url: `/hospital/order/get/${orderId}`,
      method: 'get',
    })
  },
  //取消订单
  cancelOrder(orderId){
    return request({
      url: `/hospital/order/cancel/${orderId}`,
      method: 'get',
    })
  },
}