import request from '@/utils/request' 

export default {
  //查询轮播图列表
  listBanner(){
    return request({
      url: `/hospital/banner/list`,
      method: 'get'
    })
  },
}