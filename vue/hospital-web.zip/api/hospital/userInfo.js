import request from '/utils/request'

const api_name = `/hospital/user-info`

export default {
  loginByPhone(userLoginVo) {
    return request({
      url: `${api_name}/loginByPhone`,
      method: 'post',
      data: userLoginVo,
    })
  },
  pageUserInfo(current, size, userQueryVo){
    return request({
      url:`${api_name}/${current}/${size}`,
      method: `get`,
      data: userQueryVo
    })
  },
  //获取用户信息
  getUserInfo(){
    return request({
      url: `/hospital/user-info/get`,
      method: `get`,
    })
  },
  //用户信息认证
  authUserInfo(userAuthVo){
    return request({
      url: `/hospital/user-info/auth`,
      method: `post`,
      data: userAuthVo
    })
  },
}
