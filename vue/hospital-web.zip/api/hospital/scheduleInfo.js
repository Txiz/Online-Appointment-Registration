import request from '/utils/request'

const api_name = `/hospital/schedule`

export default {
  getScheduleRule(current, size, hospitalCode, departmentCode){
    return request({
      url :`${api_name}/getScheduleRule/${current}/${size}/${hospitalCode}/${departmentCode}`,
      method:'get'
    })
  },
  getSchedule(hospitalCode, departmentCode, workDate){
    return request({
      url :`${api_name}/getSchedule/${hospitalCode}/${departmentCode}/${workDate}`,
      method: 'get'
    })
  },
  //根据医院编号和科室编号分页查询可预约排班规则
  getBookingSchedule(current, size, hospitalCode, departmentCode){
    return request({
      url :`${api_name}/getBookingSchedule/${current}/${size}/${hospitalCode}/${departmentCode}`,
      method: 'get'
    })
  }
}
