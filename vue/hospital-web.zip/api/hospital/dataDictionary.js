import request from '/utils/request'

const api_name = `/hospital/data-dictionary`

export default {
  importDataDictionary(file){
    return request({
      url :`${api_name}/import`,
      method:'post',
      data: file
    })
  },
  exportDataDictionary(){
    return request({
      url :`${api_name}/export`,
      method:'get'
    })
  },
  listDataDictionary(id){
    return request({
      url :`${api_name}/list/${id}`,
      method:'get'
    })
  },
  listByCode(code){
    return request({
      url: `${api_name}/listByCode/${code}`,
      method: 'get'
    })
  }
}
