import request from '/utils/request'

const api_name = `/hospital/hospital-set`

export default {
  saveHospitalSet(hospitalSet){
    return request({
      url: `${api_name}/save`,
      method: 'post',
      data: hospitalSet
    })
  },
  updateHospitalSet(hospitalSet){
    return request({
      url: `${api_name}/update`,
      method: 'post',
      data: hospitalSet
    })
  },
  removeHospitalSet(id){
    return request({
      url: `${api_name}/${id}`,
      method: 'delete'
    })
  },
  listHospitalSet(){
    return request({
      url: `${api_name}/list`,
      method: 'get'
    })
  },
  pageHospitalSet(current, size, hospitalSetQueryVo){
    return request({
      url: `${api_name}/page/${current}/${size}`,
      method: 'post',
      params: hospitalSetQueryVo
    })
  },
  lockHospitalSet(id, status){
    return request({
      url: `${api_name}/lock/${id}/${status}`,
      method:'put'
    })
  },
  getSignKeyById(id){
    return request({
      url: `${api_name}/getSignKey/${id}`,
      method: 'get'
    })
  }
}
