import request from '/utils/request'

const api_name = `/hospital/hospital-info`

export default {
  //查询医院列表
  pageHospitalInfo(current, size, hospitalInfoQueryVo){
    return request({
      url: `${api_name}/page/${current}/${size}`,
      method: 'post',
      params: hospitalInfoQueryVo
    })
  },
  listByHospitalName(hospitalName){
    return request({
      url: `${api_name}/listByHospitalName/${hospitalName}`,
      method: 'get'
    })
  },
  // 根据表id获取医院信息
  getHospitalInfo(id) {
    return request({
      url: `/hospital/hospital-info/${id}`,
      method: 'get'
    })
  },
  // 根据医院编号查询所有的部门科室并组装成列表树
  listDepartmentVo(hospitalCode) {
    return request({
      url: `/hospital/department/list/${hospitalCode}`,
      method: 'get'
    })
  }
}
