import request from '/utils/request'

const api_name = `/hospital/patient-info`

export default {
  savePatientInfo(patientInfo){
    return request({
      url :`${api_name}/save`,
      method:'post',
      data: patientInfo
    })
  },
  updatePatientInfo(patientInfo){
    return request({
      url :`${api_name}/update`,
      method:'post',
      data: patientInfo
    })
  },
  getPatientInfo(id){
    return request({
      url :`${api_name}/${id}`,
      method:'get'
    })
  },
  removePatientInfo(id){
    return request({
      url :`${api_name}/${id}`,
      method:'delete'
    })
  },
  listPatientInfo(){
    return request({
      url :`${api_name}/list`,
      method:'get'
    })
  }
}
