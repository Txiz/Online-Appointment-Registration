import request from '/utils/request'

const api_name = `/api/hospital/`

export default {
  saveHospitalInfo(){
    return request({
      url :`${api_name}/saveHospitalInfo`,
      method:'post'
    })
  },
  getHospitalInfoByHospitalCode(){
    return request({
      url :`${api_name}/getHospitalInfoByHospitalCode`,
      method:'post'
    })
  },
  saveDepartment(){
    return request({
      url :`${api_name}/saveDepartment`,
      method:'post'
    })
  },
  getDepartmentByHospitalCode(){
    return request({
      url :`${api_name}/getDepartmentByHospitalCode`,
      method:'post'
    })
  },
  removeDepartment(){
    return request({
      url :`${api_name}/removeDepartment`,
      method:'post'
    })
  },
  saveSchedule(){
    return request({
      url :`${api_name}/saveSchedule`,
      method:'post'
    })
  },
  getScheduleByHospitalCodeAndDepartmentCode(){
    return request({
      url :`${api_name}/getScheduleByHospitalCodeAndDepartmentCode`,
      method:'post'
    })
  },
  removeSchedule(){
    return request({
      url :`${api_name}/removeSchedule`,
      method:'post'
    })
  }
}
