import request from '@/utils/request'

export default {
  pay(orderId) {
    return request({
      url: `/task/alipay/pay/${orderId}`,
      method: 'get',
    })
  },
  queryPayStatus(orderId) {
    return request({
      url: `/task/alipay/queryPayStatus/${orderId}`,
      method: 'get',
    })
  },
}