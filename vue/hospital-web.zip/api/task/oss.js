import request from '@/utils/request'

export default {
  // 上传图片文件
  uploadPicture(file) {
    return request({
      url: `/task/oss/uploadPicture`,
      method: 'post',
      data: file
    })
  }
}
