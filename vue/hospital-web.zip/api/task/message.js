import request from '@/utils/request'

export default {
  getCode(phone) {
    return request({
      url: `/task/message/getCode/${phone}`,
      method: 'post',
    })
  },
}