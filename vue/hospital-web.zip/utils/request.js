import axios from 'axios'
import { Message } from 'element-ui'
import cookie from 'js-cookie'

// 创建axios实例
const service = axios.create({
  baseURL: 'http://localhost:8000',
  timeout: 30000
})

// http request 拦截器
service.interceptors.request.use(
  success => {
    if (cookie.get('token')) {
      success.headers['Authorization'] = cookie.get('token')
    }
    return success
  },
  error => {
    return Promise.reject(error)
  })

// http response 拦截器
service.interceptors.response.use(response => {
    if (response.data.code === 20008) {
      eventLogin.$emit('loginDialogEvent')
      return
    } else {
      if (response.data.code !== 20000) {
        Message({
          message: response.data.message,
          type: 'error',
          duration: 5 * 1000
        })
        return Promise.reject(response.data)
      } else {
        return response.data
      }
    }
  },
  error => {
    return Promise.reject(error.response)
  })

export default service
