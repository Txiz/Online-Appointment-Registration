import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _09c23ece = () => interopDefault(import('..\\pages\\notice\\index.vue' /* webpackChunkName: "pages/notice/index" */))
const _6c52d5a0 = () => interopDefault(import('..\\pages\\order\\index.vue' /* webpackChunkName: "pages/order/index" */))
const _c48faeee = () => interopDefault(import('..\\pages\\patient\\index.vue' /* webpackChunkName: "pages/patient/index" */))
const _63d6ba0a = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _d0183a9a = () => interopDefault(import('..\\pages\\hospital\\booking.vue' /* webpackChunkName: "pages/hospital/booking" */))
const _3d53adad = () => interopDefault(import('..\\pages\\hospital\\schedule.vue' /* webpackChunkName: "pages/hospital/schedule" */))
const _75035008 = () => interopDefault(import('..\\pages\\information\\agreement\\index.vue' /* webpackChunkName: "pages/information/agreement/index" */))
const _3bacae32 = () => interopDefault(import('..\\pages\\information\\contact\\index.vue' /* webpackChunkName: "pages/information/contact/index" */))
const _cc0f06ec = () => interopDefault(import('..\\pages\\information\\partner\\index.vue' /* webpackChunkName: "pages/information/partner/index" */))
const _c92f046c = () => interopDefault(import('..\\pages\\information\\privacy\\index.vue' /* webpackChunkName: "pages/information/privacy/index" */))
const _a28e55c2 = () => interopDefault(import('..\\pages\\order\\show.vue' /* webpackChunkName: "pages/order/show" */))
const _9b4616d0 = () => interopDefault(import('..\\pages\\patient\\add.vue' /* webpackChunkName: "pages/patient/add" */))
const _5d4dfdd4 = () => interopDefault(import('..\\pages\\patient\\show.vue' /* webpackChunkName: "pages/patient/show" */))
const _2c008ebe = () => interopDefault(import('..\\pages\\hospital\\detail\\_hoscode.vue' /* webpackChunkName: "pages/hospital/detail/_hoscode" */))
const _74448230 = () => interopDefault(import('..\\pages\\hospital\\notice\\_hoscode.vue' /* webpackChunkName: "pages/hospital/notice/_hoscode" */))
const _ba85d6e0 = () => interopDefault(import('..\\pages\\hospital\\_hoscode.vue' /* webpackChunkName: "pages/hospital/_hoscode" */))
const _639aa426 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/notice",
    component: _09c23ece,
    name: "notice"
  }, {
    path: "/order",
    component: _6c52d5a0,
    name: "order"
  }, {
    path: "/patient",
    component: _c48faeee,
    name: "patient"
  }, {
    path: "/user",
    component: _63d6ba0a,
    name: "user"
  }, {
    path: "/hospital/booking",
    component: _d0183a9a,
    name: "hospital-booking"
  }, {
    path: "/hospital/schedule",
    component: _3d53adad,
    name: "hospital-schedule"
  }, {
    path: "/information/agreement",
    component: _75035008,
    name: "information-agreement"
  }, {
    path: "/information/contact",
    component: _3bacae32,
    name: "information-contact"
  }, {
    path: "/information/partner",
    component: _cc0f06ec,
    name: "information-partner"
  }, {
    path: "/information/privacy",
    component: _c92f046c,
    name: "information-privacy"
  }, {
    path: "/order/show",
    component: _a28e55c2,
    name: "order-show"
  }, {
    path: "/patient/add",
    component: _9b4616d0,
    name: "patient-add"
  }, {
    path: "/patient/show",
    component: _5d4dfdd4,
    name: "patient-show"
  }, {
    path: "/hospital/detail/:hoscode?",
    component: _2c008ebe,
    name: "hospital-detail-hoscode"
  }, {
    path: "/hospital/notice/:hoscode?",
    component: _74448230,
    name: "hospital-notice-hoscode"
  }, {
    path: "/hospital/:hoscode?",
    component: _ba85d6e0,
    name: "hospital-hoscode"
  }, {
    path: "/",
    component: _639aa426,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
