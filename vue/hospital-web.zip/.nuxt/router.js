import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _ff0fe98a = () => interopDefault(import('..\\pages\\notice\\index.vue' /* webpackChunkName: "pages/notice/index" */))
const _fea970da = () => interopDefault(import('..\\pages\\order\\index.vue' /* webpackChunkName: "pages/order/index" */))
const _04882c88 = () => interopDefault(import('..\\pages\\patient\\index.vue' /* webpackChunkName: "pages/patient/index" */))
const _6286b2b0 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _26389ec0 = () => interopDefault(import('..\\pages\\hospital\\booking.vue' /* webpackChunkName: "pages/hospital/booking" */))
const _f344c540 = () => interopDefault(import('..\\pages\\hospital\\schedule.vue' /* webpackChunkName: "pages/hospital/schedule" */))
const _d216bb16 = () => interopDefault(import('..\\pages\\information\\agreement\\index.vue' /* webpackChunkName: "pages/information/agreement/index" */))
const _6cb9b7df = () => interopDefault(import('..\\pages\\information\\contact\\index.vue' /* webpackChunkName: "pages/information/contact/index" */))
const _69f4f392 = () => interopDefault(import('..\\pages\\information\\partner\\index.vue' /* webpackChunkName: "pages/information/partner/index" */))
const _6714f112 = () => interopDefault(import('..\\pages\\information\\privacy\\index.vue' /* webpackChunkName: "pages/information/privacy/index" */))
const _a13e4e68 = () => interopDefault(import('..\\pages\\order\\show.vue' /* webpackChunkName: "pages/order/show" */))
const _729532ea = () => interopDefault(import('..\\pages\\patient\\add.vue' /* webpackChunkName: "pages/patient/add" */))
const _480ecd83 = () => interopDefault(import('..\\pages\\patient\\show.vue' /* webpackChunkName: "pages/patient/show" */))
const _acf77558 = () => interopDefault(import('..\\pages\\hospital\\detail\\_hoscode.vue' /* webpackChunkName: "pages/hospital/detail/_hoscode" */))
const _f53b68ca = () => interopDefault(import('..\\pages\\hospital\\notice\\_hoscode.vue' /* webpackChunkName: "pages/hospital/notice/_hoscode" */))
const _2871f77a = () => interopDefault(import('..\\pages\\hospital\\_hoscode.vue' /* webpackChunkName: "pages/hospital/_hoscode" */))
const _74c62d93 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/notice",
    component: _ff0fe98a,
    name: "notice"
  }, {
    path: "/order",
    component: _fea970da,
    name: "order"
  }, {
    path: "/patient",
    component: _04882c88,
    name: "patient"
  }, {
    path: "/user",
    component: _6286b2b0,
    name: "user"
  }, {
    path: "/hospital/booking",
    component: _26389ec0,
    name: "hospital-booking"
  }, {
    path: "/hospital/schedule",
    component: _f344c540,
    name: "hospital-schedule"
  }, {
    path: "/information/agreement",
    component: _d216bb16,
    name: "information-agreement"
  }, {
    path: "/information/contact",
    component: _6cb9b7df,
    name: "information-contact"
  }, {
    path: "/information/partner",
    component: _69f4f392,
    name: "information-partner"
  }, {
    path: "/information/privacy",
    component: _6714f112,
    name: "information-privacy"
  }, {
    path: "/order/show",
    component: _a13e4e68,
    name: "order-show"
  }, {
    path: "/patient/add",
    component: _729532ea,
    name: "patient-add"
  }, {
    path: "/patient/show",
    component: _480ecd83,
    name: "patient-show"
  }, {
    path: "/hospital/detail/:hoscode?",
    component: _acf77558,
    name: "hospital-detail-hoscode"
  }, {
    path: "/hospital/notice/:hoscode?",
    component: _f53b68ca,
    name: "hospital-notice-hoscode"
  }, {
    path: "/hospital/:hoscode?",
    component: _2871f77a,
    name: "hospital-hoscode"
  }, {
    path: "/",
    component: _74c62d93,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
