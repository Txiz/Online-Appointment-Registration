<template>
  <div class="footer-container">
    <div class="wrapper">
      <div>
        <span class="record">京ICP备13018369号</span>
        <span class="phone">电话挂号010-56253825</span>
      </div>
      <div class="right">
        <span class="v-link clickable" :onclick="'javascript:window.location=\'/information/contact'+'\''"> 联系我们 </span>
        <span class="v-link clickable" :onclick="'javascript:window.location=\'/information/partner'+'\''"> 合作伙伴 </span>
        <span class="v-link clickable" :onclick="'javascript:window.location=\'/information/agreement'+'\''"> 用户协议 </span>
        <span class="v-link clickable" :onclick="'javascript:window.location=\'/information/privacy'+'\''"> 隐私协议 </span>
      </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>
