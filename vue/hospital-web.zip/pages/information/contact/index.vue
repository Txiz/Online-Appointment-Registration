<template>

  <!-- header -->
  <div class="nav-container page-component">
    <!--左侧导航 #start -->
    <div class="nav left-nav">
      <div class="nav-item selected">
        <span class="v-link selected dark" :onclick="'javascript:window.location=\'/information/contact'+'\''"> 联系我们 </span>
      </div>
      <div class="nav-item ">
        <span class="v-link clickable dark" :onclick="'javascript:window.location=\'/information/partner'+'\''"> 合作伙伴 </span>
      </div>
      <div class="nav-item">
        <span class="v-link clickable dark" :onclick="'javascript:window.location=\'/information/agreement'+'\''"> 用户协议 </span>
      </div>
      <div class="nav-item ">
        <span class="v-link clickable dark" :onclick="'javascript:window.location=\'/information/privacy'+'\''"> 隐私协议 </span>
      </div>
    </div>
    <!-- 左侧导航 #end -->

    <!-- 右侧内容 #start -->
    <div class="page-container">
      <div class="hospital-home">
        <div class="common-header">
          <div class="title-wrapper">
            <span class="hospital-title">联系我们</span>
          </div>
        </div>
        <div class="info-wrapper">
          <div class="content-wrapper">
            <div class="line"> 
              <i class="el-icon-phone-outline"> 电话预约挂号服务热线：114（北京用户）/ 010-114（非北京用户）</i>
            </div>
            <div class="line"> 
              <i class="el-icon-mouse"> 网上预约挂号：www.114yygh.com</i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 右侧内容 #end -->
  </div>
  <!-- footer -->
</template>

<script>
import '~/assets/css/hospital_personal.css'
import '~/assets/css/hospital.css'

export default {
  data() {
    return {
    }
  },
}
</script>
