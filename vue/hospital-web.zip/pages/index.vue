<template>
  <div class="home page-component">
    <el-carousel indicator-position="outside">
      <el-carousel-item v-for="item in bannerList" :key="item.bannerId">
        <el-image
          :src="item.bannerUrl">
        </el-image>
      </el-carousel-item>
    </el-carousel>
    <!-- 搜索 -->
    <div class="search-container">
      <div class="search-wrapper">
        <div class="hospital-search">
          <el-autocomplete
            class="search-input"
            prefix-icon="el-icon-search"
            v-model="hospitalName"
            :fetch-suggestions="querySearchAsync"
            :trigger-on-focus="false"
            @select="handleSelect"
            placeholder="点击输入医院名称">
            <span slot="suffix" class="search-btn  v-link highlight clickable selected" @click="search(hospitalName)">搜索 </span>
          </el-autocomplete>
        </div>
      </div>
    </div>
    <!-- bottom -->
    <div class="bottom">
      <div class="left">
        <div class="home-filter-wrapper">
          <div class="title"> 医院</div>
           <div>
            <div class="filter-wrapper">
              <span class="label">等级：</span>
              <div class="condition-wrapper">
                <span class="item v-link clickable" :class="hospitalTypeActiveIndex == index ? 'selected' : ''" v-for="(item,index) in hospitalTypeList" :key="item.id" @click="hostypeSelect(item.value, index)">{{ item.name }}</span>
              </div>
            </div>
            <div class="filter-wrapper">
              <span class="label">地区：</span>
              <div class="condition-wrapper">
                <span class="item v-link clickable" :class="provinceActiveIndex == index ? 'selected' : ''" v-for="(item,index) in provinceList" :key="item.id" @click="provinceSelect(item.value, index)">{{ item.name }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="v-scroll-list hospital-list">
          <div class="v-card clickable list-item" v-for="item in list" :key="item.id">
            <div class="">
              <div class="hospital-list-item hos-item" index="0" @click="show(item.id)">
                <div class="wrapper">
                  <div class="hospital-title"> {{ item.hospitalName }}</div>
                  <div class="bottom-container">
                    <div class="icon-wrapper">
                      <span class="iconfont"></span>{{ item.parameter.hospitalTypeName }}
                    </div>
                    <div class="icon-wrapper">
                      <span class="iconfont"></span>每天{{ item.bookingRule.releaseTime }}放号
                    </div>
                  </div>
                </div>
                <img :src="'data:image/jpeg;base64,'+item.logoData" :alt="item.hospitalName" class="hospital-img">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="right">
        <!-- <div class="common-dept">
          <div class="header-wrapper">
            <div class="title"> 常见科室</div>
            <div class="all-wrapper"><span>全部</span>
              <span class="iconfont icon"></span>
            </div>
          </div>
          <div class="content-wrapper">
            <span class="item v-link clickable dark">神经内科 </span>
            <span class="item v-link clickable dark">消化内科 </span>
            <span class="item v-link clickable dark">呼吸内科 </span>
            <span class="item v-link clickable dark">内科 </span>
            <span class="item v-link clickable dark">神经外科 </span>
            <span class="item v-link clickable dark">妇科 </span>
            <span class="item v-link clickable dark"> 产科 </span>
            <span class="item v-link clickable dark">儿科 </span>
          </div>
        </div> -->
        <!-- <div class="common-dept">
          <div class="header-wrapper">
            <div class="title"> 公告</div>
          </div>
        </div> -->
        <div class="space">
          <div class="header-wrapper">
            <div class="title-wrapper">
              <div class="icon-wrapper"><span
                class="iconfont title-icon"></span>
              </div>
              <span class="title">平台公告</span>
            </div>
            <div class="all-wrapper">
              <span :onclick="'javascript:window.location=\'/notice/?type='+0+'\''">全部</span>
              <span class="iconfont icon"></span>
            </div>
          </div>
          <div class="content-wrapper">
            <div class="notice-wrapper" v-for="(item,index) in platformNoticeList" :key="item.id" @click="showNotice(index,item.noticeId,0)">
              <div class="point"></div>
              <span class="notice v-link clickable dark"> {{ item.noticeTitle }}</span>
            </div>
          </div>
        </div>
        <div class="suspend-notice-list space">
          <div class="header-wrapper">
            <div class="title-wrapper">
              <div class="icon-wrapper">
                <span class="iconfont title-icon"></span>
              </div>
              <span class="title">医院公告</span>
            </div>
            <div class="all-wrapper">
              <span :onclick="'javascript:window.location=\'/notice/?type='+1+'\''">全部</span>
              <span class="iconfont icon"></span>
            </div>
          </div>
          <div class="content-wrapper">
            <div class="notice-wrapper" v-for="(item,index) in hospitalNoticeList" :key="item.id" @click="showNotice(index,item.noticeId,1)">
              <div class="point"></div>
              <span class="notice v-link clickable dark"> {{ item.noticeTitle }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import hospitalApi from '@/api/hospital/hospitalInfo'
import dictApi from '@/api/hospital/dataDictionary'
import bannerApi from '@/api/hospital/banner'
import noticeApi from '@/api/hospital/notice'

export default {
  // asyncData：渲染组件之前异步获取数据
  // asyncData({ params, error }) {
  //   return hospitalApi.pageHospitalInfo(1, 10, null).then(response => {
  //     console.log(response.data)
  //     return {
  //       list: response.data.hospitalInfoList.content,
  //       pages : response.data.totalPage
  //     }
  //   });
  // },
    data(){
      return {
          searchObj: {},
          page: 1,
          limit: 10,

          list:[],

          hospitalName: '',
          hospitalTypeList: [],
          provinceList: [],

          hospitalTypeActiveIndex: 0,
          provinceActiveIndex: 0,

          bannerList: [],

          platformNoticeList : [],
          hospitalNoticeList : [],
      }
    },
    created() {
      this.init()
      this.listBanner()
    },
    mounted() {
      // document.getElementById("search").style.display = 'node';
    
      // 添加滚动事件 ，检测滚动到页面底部
        // window.addEventListener('scroll', this.load, true)
    },
    destroyed() {
        // 页面关闭的同时，记得将这个监听器关闭，节省性能
        window.removeEventListener('scroll', this.load, false)
    },

    methods: {
      init() {
          dictApi.listByCode('HOSTPITAL_TYPE').then(response =>{
              this.hospitalTypeList = []
              this.hospitalTypeList.push({"name":"全部", "value":""})
              for(let i in response.data.DataDictionary){
                  this.hospitalTypeList.push(response.data.DataDictionary[i]);
              }
          })
          dictApi.listByCode('PROVINCE').then(response =>{
              this.provinceList = []
              this.provinceList.push({"name":"全部", "value":""})
              for(let i in response.data.DataDictionary){
                  this.provinceList.push(response.data.DataDictionary[i]);
              }
          })
          this.getList()
          noticeApi.listNotice().then(response => {
            for(let i in response.data.noticeList){
              if(response.data.noticeList[i].noticeType==0&&this.platformNoticeList.length<3)
                  this.platformNoticeList.push(response.data.noticeList[i]);
              else if(response.data.noticeList[i].noticeType==1&&this.hospitalNoticeList.length<3)
                  this.hospitalNoticeList.push(response.data.noticeList[i]);
              }
          })
      },
      listBanner(){
      bannerApi.listBanner()
        .then(res => {
            this.bannerList = res.data.bannerList
        })
      },
        load(event){
            // 滚动条高度为430 页面搜索消失，头部搜索显示
            if(event.target.scrollTop > 430) {
                document.getElementById("search").style.display = 'block';
            } else {
                document.getElementById("search").style.display = 'none';
            }

            if(event.target.clientHeight + event.target.scrollTop >= event.target.scrollHeight){
                if(this.page < this.pages){      //先判断下一页是否有数据
                    this.page = this.page + 1
                    this.getList();              //拉取接口数据
                }
            }
        },


        getList() {
            hospitalApi.pageHospitalInfo(this.page, this.limit, this.searchObj).then(response => {
                for(let i in response.data.hospitalInfoList.content){
                    this.list.push(response.data.hospitalInfoList.content[i]);
                }
                this.page = response.data.totalPage
            })
        },


        querySearchAsync(queryString, cb) {
            this.searchObj = []
            if(queryString == '') return
            hospitalApi.listByHospitalName(queryString).then(response => {
                for (let i = 0, len = response.data.hospitalInfo.length; i < len; i++) {
                    response.data.hospitalInfo[i].value = response.data.hospitalInfo[i].hospitalName
                }
                cb(response.data.hospitalInfo)
            })
        },
        handleSelect(item) {
          window.location.href = '/hospital/' + item.id
        },
        hostypeSelect(hospitalType, index) {
            this.list = []
            this.page = 1
            this.hospitalTypeActiveIndex = index
            this.searchObj.hospitalType = hospitalType
            this.getList();
        },
        provinceSelect(provinceCode, index) {
            this.list = []
            this.page = 1
            this.provinceActiveIndex = index
            this.searchObj.provinceCode = provinceCode
            this.getList();
        },
        show(id) {
          window.location.href = '/hospital/' + id
        },
        search(hospitalName) {
          this.list=[]
          this.searchObj={}
          this.page=1
          this.limit=10
          this.searchObj.hospitalName=hospitalName
          console.log(hospitalName)
            hospitalApi.pageHospitalInfo(this.page, this.limit, this.searchObj).then(response => {
                for(let i in response.data.hospitalInfoList.content){
                    this.list.push(response.data.hospitalInfoList.content[i]);
                }
                this.page = response.data.totalPage
            })
        },
        showNotice(index,noticeId,type){
          window.location.href = '/notice/?type=' +type+'&noticeId='+noticeId+'&index='+index
        }
    }
}
</script>
