<template>

  <!-- header -->
  <div v-if="notice" class="nav-container page-component">
    <!-- 左侧导航 #start -->
    <div class="nav left-nav">
        <div v-if="type==0" class="title select-title" style="margin-top: 17px; margin-right: -17px;"> 平台公告</div>
        <div v-if="type==1" class="title select-title" style="margin-top: 17px; margin-right: -17px;"> 医院公告</div>
        <div class="select-dept-wrapper">
          <div class="department-wrapper">
            <div class="hospital-department">
              <div class="dept-list-wrapper el-scrollbar" style="height: 100%;">
                <div class="dept-list el-scrollbar__wrap" style="margin-bottom: -17px; margin-right: -17px;">
                  <div class="el-scrollbar__view">
                    <div class="sub-item" v-for="(item,index) in noticeList" :key="item.id" :class="index == activeIndex ? 'selected' : ''" @click="show(index,item.noticeId)"> {{ item.noticeTitle }}</div>
                  </div>
                </div>
                <div class="el-scrollbar__bar is-horizontal">
                  <div class="el-scrollbar__thumb" style="transform: translateX(0%);"></div>
                </div>
                <div class="el-scrollbar__bar is-vertical">
                  <div class="el-scrollbar__thumb" style="transform: translateY(0%); height: 91.4761%;"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    <!-- 左侧导航 #end -->
    <!-- 右侧内容 #start -->
    <div class="page-container">
      <div class="hospital-notice">
        <div class="content"><h2>{{ notice.noticeTitle }}</h2>
          <p>{{ notice.noticeContent }}</p>
        </div>
        <div v-if="notice.createTime" align="right">创建时间：{{notice.createTime}}</div>
        <!-- <div v-if="notice.updateTime" align="right">更新时间：{{notice.updateTime}}</div> -->
      </div>
    </div>
    <!-- 右侧内容 #end -->
  </div>
  <!-- footer -->
</template>

<script>
import '~/assets/css/hospital_personal.css'
import '~/assets/css/hospital.css'

import noticeApi from '@/api/hospital/notice'

export default {
  data() {
    return {
        searchObj: {},
        page: 1,
        limit: 10,
        noticeList : [],
        notice: null,
        noticeId: null,
        type: null,
        activeIndex: null,
    }
  },
  created() {
    this.searchObj.noticeType = this.$route.query.type
    this.searchObj.isEnable = 1
    this.type=this.$route.query.type
    this.noticeId=this.$route.query.noticeId
    this.activeIndex=this.$route.query.index
    this.init()
  },
  methods: {
    init() {
      noticeApi.pageNotice(this.page, this.limit, this.searchObj).then(response => {
        this.noticeList =  response.data.noticeList
        if(!this.noticeId){
        noticeApi.getNotice(this.noticeList[0].noticeId).then(response => {
            this.notice =  response.data.notice
        })
        this.activeIndex=0
        }
        else
        noticeApi.getNotice(this.noticeId).then(response => {
            this.notice =  response.data.notice
        })
      })
    },
    show(index,noticeId){
        this.activeIndex = index
        this.noticeId=noticeId
        noticeApi.getNotice(this.noticeId).then(response => {
            this.notice =  response.data.notice
        })
    }
  }
}
</script>
